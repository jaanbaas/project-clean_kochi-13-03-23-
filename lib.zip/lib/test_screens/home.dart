import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: Text(
        "Welcome to home page",
        style: TextStyle(fontSize: 25.0),
      )),
    );
  }
}
